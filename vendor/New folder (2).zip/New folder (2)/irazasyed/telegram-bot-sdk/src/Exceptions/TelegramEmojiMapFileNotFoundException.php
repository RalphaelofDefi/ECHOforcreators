<?php

namespace Telegram\Bot\Exceptions;

/**
 * Class TelegramOtherException.
 */
final class TelegramEmojiMapFileNotFoundException extends TelegramSDKException
{
}
