<?php

namespace Telegram\Bot\Exceptions;

use Exception;

/**
 * Class TelegramUndefinedPropertyException.
 */
final class TelegramUndefinedPropertyException extends Exception
{
}
